package com.linguochao.design.action.strategy.quackbehavior;

/**
 * description
 *
 * @author linguochao
 * @date 2020\4\11 0011
 */
public	interface QuackBehavior {
    void quack();
};
