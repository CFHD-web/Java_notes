package com.linguochao.design.structure.adapter.duck;

public interface Duck {
	public void quack();
	public void fly();
}
