package com.linguochao.design.structure.decorator.coffee;

/**
 * description
 *
 * @author linguochao
 * @date 2020\4\11 0011
 */
public class ShortBlack extends Coffee{

    public ShortBlack() {
        super.setDescription("ShortBlack");
        super.setPrice(5.0f);
    }

}
