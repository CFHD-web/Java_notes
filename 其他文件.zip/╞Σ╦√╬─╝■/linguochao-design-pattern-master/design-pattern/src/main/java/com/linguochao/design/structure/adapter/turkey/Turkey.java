package com.linguochao.design.structure.adapter.turkey;


public interface Turkey {
	 void gobble();
	 void fly();
}
