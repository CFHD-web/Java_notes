package com.linguochao.design.action.template.improve;

public class RedBeanSoyaMilk extends SoyaMilk {

	@Override
	void addCondiments() {
		System.out.println(" 加入红豆 ");
	}

}
