package com.linguochao.design.structure.proxy.staticproxy;

//接口
public interface ITeacherDao {

	void teach(); // 授课的方法
}
