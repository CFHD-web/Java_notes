package com.linguochao.design.action.mediator;

import com.linguochao.design.action.mediator.colleague.*;
import com.linguochao.design.action.mediator.mediator.ConcreteMediator;
import com.linguochao.design.action.mediator.mediator.Mediator;

public class ClientTest {

	public static void main(String[] args) {
		//创建一个中介者对象
		Mediator mediator = new ConcreteMediator();

		//创建Alarm 并且加入到  ConcreteMediator 对象的HashMap
		Alarm alarm = new Alarm(mediator, "alarm");

		//创建 Curtains , 并  且加入到  ConcreteMediator 对象的HashMap
		new Curtains(mediator, "curtains");
		new TV(mediator, "TV");

		//创建了CoffeeMachine 对象，并  且加入到  ConcreteMediator 对象的HashMap
		CoffeeMachine coffeeMachine = new CoffeeMachine(mediator, "coffeeMachine");


		//让闹钟发出消息
		alarm.SendAlarm(0);
		coffeeMachine.FinishCoffee();
		alarm.SendAlarm(1);
	}

}
