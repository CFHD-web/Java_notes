package com.linguochao.design.action.template.tradition;

public class RedBeanSoyaMilk extends SoyaMilk {

	@Override
	void addCondiments() {
		System.out.println(" 加入红豆 ");
	}

}
