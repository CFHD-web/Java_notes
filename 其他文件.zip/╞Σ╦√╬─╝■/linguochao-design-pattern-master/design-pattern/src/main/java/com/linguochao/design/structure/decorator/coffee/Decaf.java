package com.linguochao.design.structure.decorator.coffee;

/**
 * description
 *
 * @author linguochao
 * @date 2020\4\11 0011
 */
public class Decaf extends Coffee {

    public Decaf() {
        super.setDescription("Decaf");
        super.setPrice(3.0f);
    }
}

