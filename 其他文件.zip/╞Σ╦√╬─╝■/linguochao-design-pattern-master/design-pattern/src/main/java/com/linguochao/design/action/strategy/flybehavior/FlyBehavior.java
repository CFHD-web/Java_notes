package com.linguochao.design.action.strategy.flybehavior;

/**
 * description
 *
 * @author linguochao
 * @date 2020\4\11 0011
 */
public interface FlyBehavior {
    void fly();
}

