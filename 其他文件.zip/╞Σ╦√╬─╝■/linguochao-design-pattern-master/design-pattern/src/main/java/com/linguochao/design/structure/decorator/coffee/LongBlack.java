package com.linguochao.design.structure.decorator.coffee;

/**
 * description
 *
 * @author linguochao
 * @date 2020\4\11 0011
 */
public class LongBlack extends Coffee{

    public LongBlack() {
        super.setDescription("LongBlack");
        super.setPrice(6.0f);
    }

}

