package com.linguochao.design.action.observer.observer;

/**
 * description
 *
 * @author linguochao
 * @date 2020\4\11 0011
 */
public interface Observer {
     void update(float mTemperatrue, float mPressure, float mHumidity);
}

