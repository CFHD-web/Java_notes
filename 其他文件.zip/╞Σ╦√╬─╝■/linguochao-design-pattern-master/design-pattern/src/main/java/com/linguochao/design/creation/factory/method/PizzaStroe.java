package com.linguochao.design.creation.factory.method;



public class PizzaStroe {

	public static void main(String[] args) {
		new	NYOrderPizza();
		new LDOrderPizza();
	}

}
